package interfaces;

import java.awt.Color;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class PadraoPainel extends JPanel{
	
	public PadraoPainel(){
		super();
		this.setLayout(null);
		this.setBackground(Color.white);
		
	}
}
