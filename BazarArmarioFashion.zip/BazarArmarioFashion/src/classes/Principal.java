package classes;

import interfaces.Janela;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Janela.getInstance(); 
	}

}